package com.dairy.Services;

import com.dairy.Entity.ContactUs;
import com.dairy.Repository.ContactUsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ContactUsService {
    @Autowired
    private ContactUsRepository repository;
    public ContactUs addData(ContactUs contactUs){
        return repository.save(contactUs);
    }
    public List<ContactUs> getAll() {
        return repository.findAll();
    }
}
