package com.dairy.Services;

import com.dairy.Dto.MilkSaleDTO;
import com.dairy.Entity.*;
import com.dairy.Repository.CollectionShiftMasterRepository;
import com.dairy.Repository.CustomerRegistrationRepository;
import com.dairy.Repository.CustomerMilkSaleRepository;
import com.dairy.Repository.MilkTypeMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class CustomerMilkSaleService {
    @Autowired
    private CustomerMilkSaleRepository repository;
    @Autowired
    private CustomerRegistrationRepository customerRepository;
    @Autowired
    private MilkTypeMasterRepository milkTypeMasterRepository;
    @Autowired
    private CollectionShiftMasterRepository collectionShiftMasterRepository;

    public CustomerMilkSale add(CustomerMilkSale customerMilkSale, int id) {
        CustomerRegistration c = customerRepository.findById(id).
                orElseThrow(() -> new RuntimeException("Customer not found"));
        ;
        customerMilkSale.setAmount(customerMilkSale.getLiter() * customerMilkSale.getRate());
        customerMilkSale.setBalance(customerMilkSale.getAmount() - customerMilkSale.getPaid());
        customerMilkSale.setCustomerRegistration(c);
        customerMilkSale.setTransactionDate(LocalDateTime.now());
        customerMilkSale.setDate(LocalDate.now());
        return repository.save(customerMilkSale);
    }

    public MilkSaleDTO getById(int id) {
        CustomerMilkSale s = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("NOT FOUND"));
        String milkType = milkTypeMasterRepository.findById(s.getMilkType())
                .map(MilkTypeMaster::getAnimalName).orElse(null);
        String shift = collectionShiftMasterRepository.findById(s.getShift())
                .map(CollectionShiftMaster::getShift).orElse(null);
        return new MilkSaleDTO(s, milkType, shift);

    }
    public List<MilkSaleDTO> getByDate(LocalDate date, int id) {
        List<CustomerMilkSale> s = repository.getByDateAndShfit(date, id);

        if (s.isEmpty()) {
            return Collections.emptyList();
        }
        List<MilkSaleDTO> dtoList = s.stream().map(customerMilkSale -> {
            String milkType = milkTypeMasterRepository.findById(customerMilkSale.getMilkType())
                    .map(MilkTypeMaster::getAnimalName)
                    .orElse(null);

            String shift = collectionShiftMasterRepository.findById(customerMilkSale.getShift())
                    .map(CollectionShiftMaster::getShift)
                    .orElse(null);

            return new MilkSaleDTO(customerMilkSale, milkType, shift);
        }).collect(Collectors.toList());

        return dtoList;
    }
    public List<MilkSaleDTO>getByDate(LocalDate date){
        List<CustomerMilkSale> s=repository.getByDate(date);
        if(s.isEmpty()){
            return Collections.emptyList();
        }
        List<MilkSaleDTO>dtoList=s.stream().map(customerMilkSale -> {
            String milkType=milkTypeMasterRepository.findById(customerMilkSale.getMilkType())
                    .map(MilkTypeMaster::getAnimalName).orElse(null);
            String shift=collectionShiftMasterRepository.findById(customerMilkSale.getShift())
                    .map(CollectionShiftMaster::getShift).orElse(null);
            return new MilkSaleDTO(customerMilkSale,milkType,shift);

        }).collect(Collectors.toList());
        return dtoList;
    }
    public List<MilkSaleDTO>getAll(){
        List<CustomerMilkSale> s=repository.findAll();
        if(s.isEmpty()){
            return Collections.emptyList();
        }
        List<MilkSaleDTO>dtoList=s.stream().map(customerMilkSale -> {
            String milkType=milkTypeMasterRepository.findById(customerMilkSale.getMilkType())
                    .map(MilkTypeMaster::getAnimalName).orElse(null);
            String shift=collectionShiftMasterRepository.findById(customerMilkSale.getShift())
                    .map(CollectionShiftMaster::getShift).orElse(null);
            return new MilkSaleDTO(customerMilkSale,milkType,shift);
        }).collect(Collectors.toList());
        return dtoList;
    }
}
