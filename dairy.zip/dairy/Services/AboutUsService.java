package com.dairy.Services;

import com.dairy.Dto.AboutUsDTO;
import com.dairy.Entity.AboutUs;
import com.dairy.Repository.AboutUsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class AboutUsService {
    @Autowired
    private AboutUsRepository repository;
    public AboutUs add(AboutUs aboutUs, MultipartFile image) throws Exception{
        aboutUs.setImageName(image.getOriginalFilename());
        aboutUs.setImageType(image.getContentType());
        aboutUs.setImageData(image.getBytes());
        return repository.save(aboutUs);
    }
    public List<AboutUsDTO> getAll(){
        return repository.findAll().stream().map(aboutUs->{
            String base64Image = Base64.getEncoder().encodeToString(aboutUs.getImageData());
             return new AboutUsDTO(
                     aboutUs.getId(),
                     aboutUs.getTitle(),
                     aboutUs.getContent(),
                     aboutUs.getImageType(),
                    base64Image
             );



        }).collect(Collectors.toList());
    }



}
