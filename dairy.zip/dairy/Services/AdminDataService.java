package com.dairy.Services;
import com.dairy.Entity.AdminData;
import com.dairy.Entity.FarmerRegistration;
import com.dairy.Repository.AdminDataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AdminDataService  {
    @Autowired
    private AdminDataRepository repository;
    public AdminData addAdminData(AdminData adminData){
        return repository.save(adminData);
    }
    public List<AdminData>getAll(){
        return repository.findAll();
    }
    public AdminData updateData(int id, AdminData updatedData) {
        AdminData existingAdminData= repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Farmer not found with ID: " + id));
        if (updatedData.getPhone() != null) {
            existingAdminData.setPhone(updatedData.getPhone());
        }
        if (updatedData.getGmail() != null) {
            existingAdminData.setGmail(updatedData.getGmail());
        }
        if (updatedData.getAddress() != null) {
            existingAdminData.setAddress(updatedData.getAddress());
        }
        return repository.save(existingAdminData);
    }

}
