package com.dairy.Services;

import com.dairy.Dto.BlogDTO;
import com.dairy.Entity.Blog;
import com.dairy.Repository.BlogRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class BlogService {
    @Autowired
    private BlogRepository repository;
    public Blog addBlog(Blog blog, MultipartFile image) throws IOException {
        blog.setImageName(image.getOriginalFilename());
        blog.setImageType(image.getContentType());
        blog.setImageData(image.getBytes());
        return  repository.save(blog);
    }
    public Blog getBlogById(int id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Blog not found with id: " + id));
    }
    public BlogDTO getBlogDTOById(int id) {
        Blog blog =repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Blog not found with id: " + id));

        BlogDTO dto = new BlogDTO();
        dto.setId(blog.getId());
        dto.setTitle(blog.getHeading());
        dto.setContent(blog.getContent());
        dto.setImageType(blog.getImageType());

        String base64Image = Base64.getEncoder().encodeToString(blog.getImageData());
        dto.setImageBase64(base64Image);

        return dto;
    }

//    public List<BlogDTO> getAllBlogs() {
//        List<Blog> blogs = repository.findAll();
//
//        return blogs.stream().map(blog -> {
//            String base64Image = Base64.getEncoder().encodeToString(blog.getImageData());
//            return new BlogDTO(
//                    blog.getId(),
//                    blog.getHeading(),
//                    blog.getContent(),
//                    blog.getImageType(),
//                    base64Image
//            );
//        }).collect(Collectors.toList());
//    }
public List<Blog> getAllBlog() {
    return repository.findAll();
}

    public List<BlogDTO> getAllBlogs() {
        return repository.findAll().stream().map(blog -> {
            String base64Image = Base64.getEncoder().encodeToString(blog.getImageData());
            return new BlogDTO(
                    blog.getId(),
                    blog.getHeading(),
                    blog.getContent(),
                    blog.getImageType(),
                    base64Image
            );
        }).collect(Collectors.toList());
    }
}
