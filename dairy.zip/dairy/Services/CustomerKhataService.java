package com.dairy.Services;

import com.dairy.Dto.CustomerKhataDTO;
import com.dairy.Entity.CustomerKhata;
import com.dairy.Entity.CustomerRegistration;
import com.dairy.Entity.PaymentMethodMaster;
import com.dairy.Repository.CustomerKhataRepository;
import com.dairy.Repository.CustomerRegistrationRepository;
import com.dairy.Repository.PaymentMethodMasterRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomerKhataService {
    @Autowired
    private CustomerKhataRepository repository;
    @Autowired
    private CustomerRegistrationRepository customerRepository;
    @Autowired
    private PaymentMethodMasterRepository paymentMethodMasterRepository;
    public  CustomerKhata add(CustomerKhata customer,int customerId){
        Optional<CustomerRegistration> c=customerRepository.findById(customerId);
        double previousBalance = repository.findLatestTransactionByCustomerId(customerId)
                .map(CustomerKhata::getBalance)
                .orElse(0.0);
        double currentBalance=previousBalance;
        if(customer.getDebit()>0){
            currentBalance-=customer.getDebit();
        }
        else if (customer.getCredit()>0) {
            currentBalance+= customer.getCredit();

        }
        customer.setBalance(currentBalance);
        customer.setTransactionDate(LocalDateTime.now());
        customer.setDate(LocalDate.now());
        customer.setCustomerRegistration(c.orElse(null));
        return repository.save(customer);
    }
    public Optional<CustomerKhata> getBalanceByCustomerId(int customerId){
        return repository.findBalanceByCustomerId(customerId);
    }
    public List<CustomerKhataDTO>getAllTransactionByCustomerId(int customerId){
        List<CustomerKhata>c=repository.getTransactionById(customerId);
        return c.stream()
                .map(customer -> new CustomerKhataDTO(customer, getPaymentMethodName(customer.getPaymentMethod())))
                .collect(Collectors.toList());
    }
    public List<CustomerKhataDTO>getAllTransaction(){
        List<CustomerKhata>c=repository.findAll();
        return c.stream()
                .map(customer->new CustomerKhataDTO(customer,getPaymentMethodName(customer.getPaymentMethod())))
                .collect(Collectors.toList());
    }
    public List<CustomerKhataDTO>getTransactionByDateByCustomerId(int customerId,LocalDate startDate,LocalDate endDate){
        List<CustomerKhata> c=repository.getTransactionByDatesByFarmer(customerId,startDate,endDate);
        return c.stream()
                .map(customer->new CustomerKhataDTO(customer,getPaymentMethodName(customer.getPaymentMethod())))
                .collect(Collectors.toList());
    }
    public List<CustomerKhataDTO>getTransaction(LocalDate startDate,LocalDate endDate){
        List<CustomerKhata>c=repository.getTransactionByDates(startDate,endDate);
        return c.stream()
                .map(customer->new CustomerKhataDTO(customer,getPaymentMethodName(customer.getPaymentMethod())))
                .collect(Collectors.toList());
    }
    public int deleteByCustomerId(int customerId) {
        return repository.deleteByCustomerId(customerId); // Returns number of deleted rows
    }


    private String getPaymentMethodName(int paymentMethodId){
        return paymentMethodMasterRepository.findById(paymentMethodId)
                .map(PaymentMethodMaster::getPaymentMethod).orElse("unknown");
    }


}
