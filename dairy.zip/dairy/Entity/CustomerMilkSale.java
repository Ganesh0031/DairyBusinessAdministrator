package com.dairy.Entity;

import com.fasterxml.jackson.annotation.JsonBackReference;
import jakarta.persistence.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
public class CustomerMilkSale {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private  int id;;
    private int milkType;
    private int shift;
    private double liter;
    private double fat;
    private double rate;
    private double amount;
    private double paid;
    private double balance;
    private LocalDate date;
    private LocalDateTime TransactionDate;
    @ManyToOne
    @JoinColumn(name = "customer_id")
    @JsonBackReference
    private CustomerRegistration customerRegistration;

    public CustomerMilkSale() {
    }

    public CustomerMilkSale(int id, int milkType, int shift, double liter, double fat, double rate, double amount, double paid, double balance, LocalDate date, LocalDateTime transactionDate, CustomerRegistration customerRegistration) {
        this.id = id;
        this.milkType = milkType;
        this.shift = shift;
        this.liter = liter;
        this.fat = fat;
        this.rate = rate;
        this.amount = amount;
        this.paid = paid;
        this.balance = balance;
        this.date = date;
        TransactionDate = transactionDate;
        this.customerRegistration = customerRegistration;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getMilkType() {
        return milkType;
    }

    public void setMilkType(int milkType) {
        this.milkType = milkType;
    }

    public int getShift() {
        return shift;
    }

    public void setShift(int shift) {
        this.shift = shift;
    }

    public double getLiter() {
        return liter;
    }

    public void setLiter(double liter) {
        this.liter = liter;
    }

    public double getFat() {
        return fat;
    }

    public void setFat(double fat) {
        this.fat = fat;
    }

    public double getRate() {
        return rate;
    }

    public void setRate(double rate) {
        this.rate = rate;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getPaid() {
        return paid;
    }

    public void setPaid(double paid) {
        this.paid = paid;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }

    public LocalDate getDate() {
        return date;
    }

    public void setDate(LocalDate date) {
        this.date = date;
    }

    public LocalDateTime getTransactionDate() {
        return TransactionDate;
    }

    public void setTransactionDate(LocalDateTime transactionDate) {
        TransactionDate = transactionDate;
    }

    public CustomerRegistration getCustomerRegistration() {
        return customerRegistration;
    }

    public void setCustomerRegistration(CustomerRegistration customerRegistration) {
        this.customerRegistration = customerRegistration;
    }
}
