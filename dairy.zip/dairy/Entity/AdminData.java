package com.dairy.Entity;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class AdminData {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int id;
    private String phone;
    private String address;
    private String gmail;

    public AdminData() {
    }

    public AdminData(int id, String phone, String address, String gmail) {
        this.id = id;
        this.phone = phone;
        this.address = address;
        this.gmail = gmail;
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getGmail() {
        return gmail;
    }

    public void setGmail(String gmail) {
        this.gmail = gmail;
    }
}
