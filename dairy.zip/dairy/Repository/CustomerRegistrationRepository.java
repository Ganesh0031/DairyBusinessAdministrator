package com.dairy.Repository;

import com.dairy.Entity.CustomerRegistration;
import com.dairy.Entity.DairyRegistration;
import com.dairy.Entity.FarmerRegistration;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface CustomerRegistrationRepository  extends JpaRepository<CustomerRegistration,Integer> {
    @Query(value = "SELECT * FROM customer_registration WHERE dairy_id = :dairy_id", nativeQuery = true)
    List<CustomerRegistration> findByForeignKey(@Param("dairy_id") int dairy_id);
    boolean existsByCodeAndDairyRegistration(int code, DairyRegistration dairyRegistration);
    boolean existsByMobileAndDairyRegistration(String mobile, DairyRegistration dairyRegistration);
    @Query(value="SELECT *FROM customer_registration WHERE dairy_id= :dairy_id and id= :id",nativeQuery = true)
    CustomerRegistration findByForeginKeyCustomer(@Param("dairy_id") int dairy_id, @Param("id") int id);
}
