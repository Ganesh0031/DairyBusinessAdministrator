package com.dairy.Repository;

import com.dairy.Entity.CustomerInvoice;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.util.List;

@Repository
public interface CustomerInvoiceRepository extends JpaRepository<CustomerInvoice,Integer> {
    @Query(value = "SELECT * FROM customer_invoice WHERE customer_id= :customer_id AND date BETWEEN :startDate AND  :endDate" ,nativeQuery = true)
    List<CustomerInvoice>getByDate(@Param("customer_id")int customer_id, @Param("startDate")LocalDate startDate ,@Param("endDate") LocalDate endDate);
}
