package com.dairy.Repository;

import com.dairy.Entity.AdminData;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminDataRepository extends JpaRepository<AdminData,Integer> {
}
