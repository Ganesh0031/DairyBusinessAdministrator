package com.dairy.Repository;

import com.dairy.Entity.CustomerMilkSale;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface CustomerMilkSaleRepository extends JpaRepository<CustomerMilkSale,Integer> {
    @Query(value="SELECT * FROM customer_milk_sale WHERE date= :date AND shift=  :shift ;",nativeQuery = true)
    List<CustomerMilkSale>getByDateAndShfit(@PathVariable("date")LocalDate date, @PathVariable("shift") int shift);
    @Query(value = "SELECT * FROM customer_milk_sale WHERE date= :date ;",nativeQuery = true)
    List<CustomerMilkSale>getByDate(@PathVariable("date")LocalDate date);
    @Query(value="SELECT amount FROM customer_milk_sale WHERE customer_id= :customer_id ORDER BY date ;",nativeQuery = true)
    List<Double>add(@PathVariable("customer_id")int customer_id);
    @Query(value = "SELECT paid FROM customer_milk_sale WHERE customer_id= :customer_id ORDER BY date;",nativeQuery = true)
    List<Double>getpaid(@PathVariable("customer_id")int customer_id);
    @Query(value="SELECT amount FROM customer_milk_sale WHERE customer_id= :customer_id AND date BETWEEN :startDate AND :endDate",nativeQuery = true)
    List<Double>getAmountByDate(@PathVariable ("customer_id") int customer_id, @Param("startDate") LocalDate startDate, @Param("endDate")LocalDate endDate);
    @Query(value="SELECT paid FROM customer_milk_sale WHERE customer_id= :customer_id AND date BETWEEN :startDate AND :endDate",nativeQuery = true)
    List<Double>getPaidByDate(@PathVariable("customer_id") int customer_id,@Param("startDate")LocalDate startDate,@Param("endDate")LocalDate endDate);
}
