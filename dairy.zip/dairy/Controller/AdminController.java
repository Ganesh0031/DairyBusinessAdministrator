package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Entity.Admin;
import com.dairy.Entity.AdminData;
import com.dairy.Services.AdminService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:3000")
@RequestMapping("/api/admin")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @PostMapping("/login")
    public ResponseDTO loginAdmin(@RequestBody Admin adminData) {

        ResponseDTO response = new ResponseDTO();
        try {
            boolean isValid = adminService.validateAdmin(adminData.getUsername(), adminData.getPassword());
            if (isValid) {
                response.data =  adminData.getPassword();  // Just for example, not recommended
                response.success = true;
                response.status = 200L;
                response.message = "Login successful";
            } else {
                response.data = null;
                response.success = false;
                response.status = 401L;
                response.message = "Invalid credentials";
            }
        } catch (Exception e) {
            response.data = null;
            response.success = false;
            response.status = 500L;
            response.message = "Server error: " + e.getMessage();
        }
        return response;
    }

}

