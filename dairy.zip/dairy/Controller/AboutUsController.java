package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Entity.AboutUs;
import com.dairy.Entity.Blog;
import com.dairy.Services.AboutUsService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/AboutUs")
public class AboutUsController {
    @Autowired
    private AboutUsService service;
    @Autowired
    private ObjectMapper objectMapper;
    @PostMapping(path = "/add", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseDTO add(@RequestPart ("aboutUs") String aboutUsJson,
                       @RequestPart ("imageFile") MultipartFile imageFile ) {
        ResponseDTO response = new ResponseDTO();
        try {
            AboutUs about = objectMapper.readValue(aboutUsJson, AboutUs.class);
            response.data = service.add(about, imageFile);
            response.status = 200L;
            response.message = "Success";
            response.success = true;
        } catch (Exception e) {
            response.status = 500L;
            response.message = "Failed: " + e.getMessage();
            response.success = false;
        }
        return response;

    }
    @GetMapping("/get")
    public ResponseDTO getAllBlogsWithImages() {
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=service.getAll();
            response.status=200L;
            response.message="success";
            response.success=true;
        } catch (Exception e) {
            response.status=500L;
            response.message="Failed :"+e.getMessage();
            response.success=false;
        }
        return response;

    }
}
