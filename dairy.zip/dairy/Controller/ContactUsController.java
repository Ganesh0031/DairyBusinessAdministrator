package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Entity.ContactUs;
import com.dairy.Services.ContactUsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/ContactUs")
public class ContactUsController {
    @Autowired
    private ContactUsService contactUsService;
    @PostMapping("/add")
  public ResponseDTO add(@RequestBody ContactUs contactUs){
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=contactUsService.addData(contactUs);
            response.success=true;
            response.message="Success";
            response.status=200L;
        } catch (Exception e) {
            response.message="Failed";
            response.success=false;
            response.status=500L;
        }
        return response;
    }
    @GetMapping("/getAll")
    public ResponseDTO getAll(){
        ResponseDTO response=new ResponseDTO();
        try {
              response.data=contactUsService.getAll();
              response.success=true;
              response.status=200L;
              response.message="Success";
            } catch (Exception e) {
            response.success=false;
            response.status=500L;
            response.message="Failed";
        }
        return response;
        }

}
