package com.dairy.Controller;

import com.dairy.Dto.BlogDTO;
import com.dairy.Dto.ResponseDTO;
import com.dairy.Entity.Blog;
import com.dairy.Services.BlogService;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/Blog")
public class BlogController {
    @Autowired
    private BlogService service;

    @Autowired
    private ObjectMapper objectMapper;

    @PostMapping(path = "/add", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseDTO addBlog(@RequestPart("blog") String blogJson,
                               @RequestPart("imageFile") MultipartFile imageFile) {
        ResponseDTO response = new ResponseDTO();
        try {
            Blog blog = objectMapper.readValue(blogJson, Blog.class);
            response.data = service.addBlog(blog, imageFile);
            response.status = 200L;
            response.message = "Success";
            response.success = true;
        } catch (Exception e) {
            response.status = 500L;
            response.message = "Failed: " + e.getMessage();
            response.success = false;
        }
        return response;
    }
    @GetMapping("/get/{id}")
    public ResponseEntity<BlogDTO> getBlogWithImageById(@PathVariable int id) {
        BlogDTO blogDTO = service.getBlogDTOById(id);
        return ResponseEntity.ok(blogDTO);
    }
    @GetMapping("/get")
    public ResponseDTO getAllBlogsWithImages() {
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=service.getAllBlogs();
            response.status=200L;
            response.message="success";
            response.success=true;
        } catch (Exception e) {
            response.status=500L;
            response.message="Failed :"+e.getMessage();
            response.success=false;
        }
        return response;

    }




}