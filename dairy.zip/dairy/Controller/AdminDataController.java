package com.dairy.Controller;

import com.dairy.Dto.ResponseDTO;
import com.dairy.Entity.AdminData;
import com.dairy.Entity.FarmerRegistration;
import com.dairy.Services.AdminDataService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@CrossOrigin(origins = "http://localhost:5173")
@RequestMapping("/api/AdminData")
public class AdminDataController {
    @Autowired
    private AdminDataService service;
   @PostMapping("/add")
    public ResponseDTO add(@RequestBody AdminData adminData){
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=service.addAdminData(adminData);
            response.success=true;
            response.status=200L;
            response.message="Success";
        } catch (Exception e) {
            response.success=false;
            response.status=500L;
            response.message="Failed";
        }
        return response;
    }
    @GetMapping("/getAll")
    public ResponseDTO getData(){
        ResponseDTO response=new ResponseDTO();
        try{
            response.data=service.getAll();
            response.success=true;
            response.status=200L;
            response.message="Success";
        } catch (Exception e) {
            response.success=false;
            response.status=500L;
            response.message="Failed";
        }
        return response;
    }
    @PutMapping("/update/{id}")
    public ResponseDTO updateFarmer(
            @PathVariable int id,
            @RequestBody AdminData adminData) {
        ResponseDTO response=new ResponseDTO();
        try {
            response.data= service.updateData(id, adminData);
            response.message="Success";
            response.success=true;
            response.status=200l;
        }catch (Exception e){
            response.message="Not get data..";
            response.success=false;
            response.status=500L;
        }
        return response;
    }
}
