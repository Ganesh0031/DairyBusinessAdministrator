package com.dairy.Dto;

public class AboutUsDTO {
    private  int id;
    private  String title;
    private  String content;
    private  String imageType;
    private  String imageBase64;

    public AboutUsDTO(int id, String title, String content, String imageType, String imageBase64) {
        this.id = id;
        this.title = title;
        this.content = content;
        this.imageType = imageType;
        this.imageBase64 = imageBase64;
    }

    public AboutUsDTO() {
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getImageType() {
        return imageType;
    }

    public void setImageType(String imageType) {
        this.imageType = imageType;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public void setImageBase64(String imageBase64) {
        this.imageBase64 = imageBase64;
    }
}
